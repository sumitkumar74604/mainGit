'''
TwoDList([row][col]) : It is a collection of OneD List.
'''
r1 = [10,20,30]
r2 = [40,50,60]
r3 = [70,80,90]

twoDList = [r1,r2,r3]
print(twoDList)

#access single record 
print(twoDList[1][1])
print(twoDList[0][2])
print(twoDList[2][0])

#access all list
for row in range(len(twoDList)):
    #print(twoDList[row])
    for col in range(len(twoDList[row])):
        print("twoDList[",row,"][",col,"]:",twoDList[row][col])
